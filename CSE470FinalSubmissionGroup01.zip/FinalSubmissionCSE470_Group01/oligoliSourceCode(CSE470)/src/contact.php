<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html lang="en" class="ie8"> <![endif]-->
<!--[if !IE]><!--> <html lang="en"> <!--<![endif]-->

<head>
	<meta charset="utf-8">
	<title>Oligoli.com</title>
	<meta name="description" content="">
	<meta name="author" content="">

	<!-- Mobile Specific Meta -->
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

    <!--    changed -->
    
	<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="css/bootstrap.min.css">

<!-- Optional theme -->
<link rel="stylesheet" href="css/bootstrap-theme.min.css">

<!-- Latest compiled and minified JavaScript -->
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery-1.11.3.min.js"></script>
    
    
<!--    changed -->
    
</head>
<style type="text/css">
body{
  background-color: #DCDCDC;
  margin-left: 10px;
}
</style>
<body>
<div class="container" style="margin-left:100px;margin-top:20px">



<hr>
    <div class="header-bg">
    <div class="navbar-collapse collapse">
    
    <div class="navbar navbar-inverse navbar-fixed-top" id="myNavbar">
      <div class="navbar-header">
   <div style="margin-left:50px">
    <h1 style="color:white;">
   Oligoli
   </h1>
  </div>
    </div>
<div style="margin-right:50px">
        <ul class="nav navbar-nav navbar-right sm">
        <li><a href="home.php" style="color:white;" role="button"><b>Home</b></a></li>>
        <li><a href="contact.php" style="color:white;" role="button" ><b>Contact</b></a></li>
            <li><a href="systemdashboard.php" style="color:white;" role="button"><b>DashBoard</b></a></li>
              
        </li>
      </ul>
</div>
    </div>
     </div>
    </div><hr> 

</div>
   <div class="col-lg-4" style="background-color:;margin-left:50px;" id="contact">
<div class="container" style="background-color:; margin-right:210px; margin-left:0px; max-width:1100px; width:1050px; min-width:200px;">
            <div class="empty">  <br> <br></div>

    <div class="row">
    <div class="col-lg-4">
        <div class="row">
        <div class="contact_info">
              <h3>Find Us Here</h3>
                <div class="map">
                  <iframe width="100%" height="175" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.co.in/maps?f=q&amp;source=s_q&amp;hl=en&amp;geocode=&amp;q=Via+Piave,+124,+30171+Venezia,+Italy&amp;aq=4&amp;oq=light&amp;sll=45.486108,12.2336549&amp;sspn=0.04941,0.104628&amp;ie=UTF8&amp;hq=&amp;hnear=Via+Piave,+124,+30171+Venezia,+Italy&amp;t=m&amp;z=14&amp;ll=45.486108,12.2336549&amp;output=embed"></iframe><br><small><a href="https://maps.google.co.in/maps?f=q&amp;source=embed&amp;hl=en&amp;geocode=&amp;q=Via+Piave,+124,+30171+Venezia,+Italy&amp;aq=4&amp;oq=light&amp;sll=45.486108,12.2336549&amp;sspn=0.04941,0.104628&amp;ie=UTF8&amp;hq=&amp;hnear=Via+Piave,+124,+30171+Venezia,+Italy&amp;t=m&amp;z=14&amp;ll=45.486108,12.2336549" style="color:#666;text-align:left;font-size:0.85em">View Larger Map</a></small>
                </div>
              </div></div>
                <div class="empty">  <br> <br></div>
<div class="row">
            <div class="company_address">
              <h3>Company Information :</h3>
                  <p>VIA - PIAVE 124,</p>
                  <p>30171 MESTRE (VE),</p>
                  <p>ITALY.</p>
              <p>Mobile:+39 3273387768 , +39 3881551855</p>
              <p>Telephone & Fax: +39 041 4763477</p>
            <p>Email: <span>info@onannotravel.com</span></p>
              <p>Follow us on: <span><a href="https://www.facebook.com/Onannotravel"> Facebook </a> </span>, <span><a href="">Instagram</a>, </span>
                            <span><a href="https://twitter.com/onannotravel">                 Twitter</a> </span>
                    
                    </p>
           </div>
        </div>
        </div>
    <div class="col-lg-8">
        <div class="form">
            <h3 style="margin-left:50px;">Contact Us</h3>
              <form class="form-horizontal">
  <div class="form-group">
    <label for="inputEmail3" class="col-sm-2 control-label">Name</label>
    <div class="col-sm-10">
      <input type="email" class="form-control" id="inputEmail3" placeholder="Name">
    </div>
  </div>
    <div class="form-group">
    <label for="inputEmail3" class="col-sm-2 control-label">Email</label>
    <div class="col-sm-10">
      <input type="email" class="form-control" id="inputEmail3" placeholder="Email">
    </div>
  </div>
  <div class="form-group">
    <label for="inputPassword3" class="col-sm-2 control-label">Mobile</label>
    <div class="col-sm-10">
      <input type="password" class="form-control" id="inputPassword3" placeholder="Password">
    </div>      
  </div>
  <div class="form-group">
    <label for="inputPassword3" class="col-sm-2 control-label">Subject</label>
    <div class="col-sm-10">
    <textarea class="form-control" rows="3"></textarea></div>      
  </div>
  <div class="form-group">
    <div class="col-sm-offset-2 col-sm-10">
      <button type="submit" class="btn btn-primary">Submit</button>
    </div>
  </div>
</form>
            </div>
        </div>
    </div>
    
    
            </div>
   </div>
        

 
<!-- /////////////////////////////////////////////////////////////////////////////////// -->
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>		
	<script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>	
	<script>window.jQuery || document.write('<script src="js/jquery-1.10.2.min.js"><\/script>')</script>
	<script src="js/bootstrap.min.js"></script>
<!--    <script src="js/owl.carousel.min.js"></script>
    <script src="js/main.js"></script>-->
</body>
</html>
