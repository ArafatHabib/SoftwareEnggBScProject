<?php
ob_start();
session_start();
$_SESSION['Username']="";
$_SESSION['area']="";
$_SESSION['type']="";
$_SESSION['title']="";
?>