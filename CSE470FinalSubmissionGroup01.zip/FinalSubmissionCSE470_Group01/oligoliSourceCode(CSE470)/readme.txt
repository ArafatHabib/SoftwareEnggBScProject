
/*
Source code documentation.
Project: OliGoli
Group 01
*/

First open the Home.php

You will find different options available. Decide if you want to sign up as 
a service provider or a user opting services. 

User:

There is an option at the top to post task.Post task as you want.
You will find the available taskers available in your area and
assign task to a particylar developer you like.

Click on myprofile button on the top to view your profile and 
posted task.

Do not forget to Lougout when you are done.

Tasker:

Logged in as a tasker? View your myprofile and you will find there
if any work is available as notification.

There will be customer review. See if the work suits you. Then either 
accept it or reject.

If you accept the work, the accepted work will be added to your profile.

Do not like your customer? Payment is not OK? Give a horrible review 
to the customer.

Admin:

Open AdminLogin.php to go to the admin panel.

Username: abusufian
password: 123456

The admin can view how many taskers, users, tasks, etc from this panel.


N.B:

Click on the dashboard button to see the ratio of the number of the user, tasker, posted tasks against time(day).
 